class ContactMe{
    constructor(first, last, email, phone, message){
        this.first = first;
        this.last = last;
        this.email = email;
        this.phone = phone;
        this.message = message;
    }

}